package FlightData;

import java.io.IOException;

import com.opencsv.CSVParser;

public class Test {
	
	private final static String LINE = "1987,10,14,3,741,730,912,849,PS,1451,NA,91,79,NA,23,11,SAN,SFO,447,NA,NA,0,NA,0,NA,NA,NA,NA,NA";
	
	public static void testReading(){
		String[] line = null;
		line = LINE.toString().split(",");
		int arrDelay = 0;
		int depDelay = 0;
		int delay = 0;
		arrDelay = Integer.parseInt(line[14]);
		depDelay = Integer.parseInt(line[15]);
		delay = Math.abs(arrDelay) + Math.abs(depDelay);
		System.out.println(line[8]+","+delay);
	}
	
	public void testReadingOneLine(){
		String[] lines = null;
		try {  
            // 用opencsv解析  
            lines = new CSVParser().parseLine(LINE);  
        }catch (IOException e) {  
            // TODO Auto-generated catch block  
            e.printStackTrace();  
        }  
        // 打印解析结果  
        for (String line : lines) {  
            System.out.println(line);  
        }  
		
	}
	
	public static void main(String[] args){
//		Test csvProcessingTest = new Test();  
//		csvProcessingTest.testReadingOneLine();  
		testReading();
	}
}
